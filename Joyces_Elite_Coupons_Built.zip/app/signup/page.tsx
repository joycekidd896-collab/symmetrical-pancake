import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import SignupForm from "./signup-form";

export default async function SignupPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (user) redirect("/");
  return (
    <div className="mx-auto max-w-sm">
      <h1 className="mb-6 text-2xl font-bold">Create an Account</h1>
      <SignupForm />
      <p className="mt-4 text-center text-sm text-gray-500">
        Already have an account? <a href="/login" className="font-medium text-brand-600">Sign in</a>
      </p>
    </div>
  );
}