"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function SignupForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setErrorMessage(null);

    const { error } = await createClient().auth.signUp({
      email,
      password,
      options: { emailRedirectTo: `${window.location.origin}/auth/callback` }
    });

    setSubmitting(false);
    if (error) {
      setErrorMessage(error.message);
      return;
    }
    setSubmitted(true);
  }

  if (submitted) {
    return (
      <div className="rounded-xl border bg-green-50 p-6 text-green-800">
        <p className="font-medium">Check your email</p>
        <p className="mt-1 text-sm">We sent a confirmation link to <strong>{email}</strong>.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="rounded-xl border bg-white p-6 shadow-sm">
      <div className="mb-4">
        <label className="mb-1 block text-sm font-medium">Email</label>
        <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full rounded-lg border px-3 py-2 text-sm" autoComplete="email" />
      </div>
      <div className="mb-4">
        <label className="mb-1 block text-sm font-medium">Password</label>
        <input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} className="w-full rounded-lg border px-3 py-2 text-sm" autoComplete="new-password" />
      </div>
      {errorMessage && <p className="mb-4 text-sm text-red-600">{errorMessage}</p>}
      <button type="submit" disabled={submitting} className="w-full rounded-lg bg-brand-600 px-5 py-2.5 font-medium text-white hover:bg-brand-700 disabled:opacity-60">
        {submitting ? "Creating account..." : "Sign Up"}
      </button>
    </form>
  );
}