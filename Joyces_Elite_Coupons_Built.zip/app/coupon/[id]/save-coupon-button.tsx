"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function SaveCouponButton({ couponId }: { couponId: string }) {
  const [status, setStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [token, setToken] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  async function handleSave() {
    setStatus("saving");
    setErrorMessage(null);

    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      setStatus("error");
      setErrorMessage("Please sign in to get this coupon.");
      return;
    }

    const { data, error } = await supabase
      .from("coupon_saves")
      .insert({ coupon_id: couponId, customer_id: user.id })
      .select("redemption_token")
      .single();

    if (error) {
      setStatus("error");
      setErrorMessage(error.message);
      return;
    }

    setToken(data.redemption_token);
    setStatus("saved");
  }

  if (status === "saved" && token) {
    return (
      <div className="rounded-lg bg-green-50 p-4 text-green-800">
        <p className="font-medium">Coupon saved!</p>
        <p className="mt-1 text-sm">Show this redemption code to the merchant:</p>
        <p className="mt-2 break-all font-mono text-lg font-bold tracking-wider">{token}</p>
      </div>
    );
  }

  return (
    <div>
      <button onClick={handleSave} disabled={status === "saving"} className="rounded-lg bg-brand-600 px-5 py-2.5 font-medium text-white hover:bg-brand-700 disabled:opacity-60">
        {status === "saving" ? "Saving..." : "Get This Coupon"}
      </button>
      {status === "error" && <p className="mt-2 text-sm text-red-600">{errorMessage}</p>}
    </div>
  );
}