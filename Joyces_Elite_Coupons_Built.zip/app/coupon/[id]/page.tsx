import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import SaveCouponButton from "./save-coupon-button";

export default async function CouponDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: coupon } = await supabase
    .from("coupons")
    .select("id, title, description, expires_at, starts_at, status, merchants(id, business_name)")
    .eq("id", id)
    .single();

  if (!coupon) notFound();

  const merchant = Array.isArray(coupon.merchants) ? coupon.merchants[0] : coupon.merchants;

  return (
    <div className="mx-auto max-w-xl rounded-xl border bg-white p-8 shadow-sm">
      <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">{merchant?.business_name ?? "Local Merchant"}</p>
      <h1 className="mt-1 text-2xl font-bold">{coupon.title}</h1>
      {coupon.description && <p className="mt-3 text-gray-600">{coupon.description}</p>}
      {coupon.expires_at && <p className="mt-4 text-sm text-gray-400">Expires {new Date(coupon.expires_at).toLocaleDateString()}</p>}
      <div className="mt-6"><SaveCouponButton couponId={coupon.id} /></div>
    </div>
  );
}