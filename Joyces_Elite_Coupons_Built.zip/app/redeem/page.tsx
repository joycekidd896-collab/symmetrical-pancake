import { createClient } from "@/lib/supabase/server";
import RedeemForm from "./redeem-form";

export default async function RedeemPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return <div className="rounded-lg border border-dashed p-8 text-center text-gray-500">Please sign in as merchant staff to redeem coupons.</div>;

  const { data: merchants } = await supabase
    .from("merchants")
    .select("id, business_name, is_approved, is_active, owner_user_id")
    .eq("owner_user_id", user.id)
    .limit(1);

  const merchant = merchants?.[0];

  if (!merchant) return <div className="rounded-lg border border-dashed p-8 text-center text-gray-500">No merchant found for your account.</div>;

  return (
    <div className="mx-auto max-w-md">
      <h1 className="mb-6 text-2xl font-bold">Redeem a Coupon</h1>
      <RedeemForm merchantId={merchant.id} />
    </div>
  );
}