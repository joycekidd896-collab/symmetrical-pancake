"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function RedeemForm({ merchantId }: { merchantId: string }) {
  const [token, setToken] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("loading");
    setMessage(null);

    const { error } = await createClient().rpc("redeem_coupon", {
      p_redemption_token: token.trim(),
      p_merchant_id: merchantId
    });

    if (error) {
      setStatus("error");
      setMessage(error.message);
      return;
    }

    setStatus("done");
    setMessage("Coupon redeemed successfully!");
    setToken("");
  }

  return (
    <form onSubmit={handleSubmit} className="rounded-xl border bg-white p-6 shadow-sm">
      <label className="mb-1 block text-sm font-medium">Customer redemption code</label>
      <input required value={token} onChange={(e) => setToken(e.target.value)} className="w-full rounded-lg border px-3 py-2 font-mono text-sm" placeholder="Paste the code" />
      <button type="submit" disabled={status === "loading"} className="mt-4 w-full rounded-lg bg-brand-600 px-5 py-2.5 font-medium text-white hover:bg-brand-700 disabled:opacity-60">
        {status === "loading" ? "Redeeming..." : "Redeem"}
      </button>
      {message && <p className={`mt-3 text-sm ${status === "error" ? "text-red-600" : "text-green-700"}`}>{message}</p>}
    </form>
  );
}