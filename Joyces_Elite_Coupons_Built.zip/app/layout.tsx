import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "Joyce's Elite Coupons",
  description: "Local deals, digital coupons, and merchant offers."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <header className="border-b bg-white">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
            <Link href="/" className="text-xl font-bold text-gray-900">
              Joyce's Elite Coupons
            </Link>
            <nav className="flex items-center gap-4 text-sm">
              <Link href="/" className="hover:text-brand-600">Deals</Link>
              <Link href="/merchant" className="hover:text-brand-600">Merchant</Link>
              <Link href="/redeem" className="hover:text-brand-600">Redeem</Link>
              <Link href="/login" className="hover:text-brand-600">Sign In</Link>
            </nav>
          </div>
        </header>
        <main className="mx-auto min-h-[calc(100vh-73px)] max-w-6xl px-4 py-8">
          {children}
        </main>
      </body>
    </html>
  );
}