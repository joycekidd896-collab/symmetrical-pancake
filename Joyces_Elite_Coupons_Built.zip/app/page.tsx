import { createClient } from "@/lib/supabase/server";
import type { Coupon } from "@/lib/types";
import Link from "next/link";

export const revalidate = 60;

export default async function BrowsePage() {
  const supabase = await createClient();

  const { data: coupons, error } = await supabase
    .from("coupons")
    .select("id, title, description, expires_at, merchants(id, business_name)")
    .eq("status", "active")
    .order("created_at", { ascending: false });

  if (error) {
    return <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-red-700">Couldn't load coupons: {error.message}</div>;
  }

  const typedCoupons = (coupons ?? []) as Coupon[];

  if (!typedCoupons.length) {
    return <div className="rounded-lg border border-dashed p-8 text-center text-gray-500">No active coupons right now — check back soon!</div>;
  }

  return (
    <div>
      <div className="mb-8">
        <p className="text-sm font-semibold uppercase tracking-wide text-brand-600">Local savings</p>
        <h1 className="mt-1 text-3xl font-bold">Active Deals</h1>
        <p className="mt-2 text-gray-600">Save money with digital coupons from participating merchants.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {typedCoupons.map((coupon) => (
          <Link key={coupon.id} href={`/coupon/${coupon.id}`} className="rounded-xl border bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
            <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">{coupon.merchants?.business_name ?? "Local Merchant"}</p>
            <h2 className="mt-1 text-lg font-semibold">{coupon.title}</h2>
            {coupon.description && <p className="mt-2 line-clamp-2 text-sm text-gray-600">{coupon.description}</p>}
            {coupon.expires_at && <p className="mt-3 text-xs text-gray-400">Expires {new Date(coupon.expires_at).toLocaleDateString()}</p>}
          </Link>
        ))}
      </div>
    </div>
  );
}