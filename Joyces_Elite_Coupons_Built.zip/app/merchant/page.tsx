import { createClient } from "@/lib/supabase/server";
import NewCouponForm from "./new-coupon-form";

export default async function MerchantDashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return <div className="rounded-lg border border-dashed p-8 text-center text-gray-500">Please sign in to view your merchant dashboard.</div>;

  const { data: merchants } = await supabase
    .from("merchants")
    .select("id, business_name, is_approved, is_active, owner_user_id")
    .eq("owner_user_id", user.id)
    .limit(1);

  const merchant = merchants?.[0];

  if (!merchant) return <div className="rounded-lg border border-dashed p-8 text-center text-gray-500">No merchant profile found for your account yet.</div>;

  const { data: coupons } = await supabase
    .from("coupons")
    .select("id, title, description, status, total_redemptions, expires_at, merchant_id")
    .eq("merchant_id", merchant.id)
    .order("created_at", { ascending: false });

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{merchant.business_name}</h1>
        <p className="text-sm text-gray-500">{merchant.is_approved ? "Approved merchant" : "Pending admin approval"}</p>
      </div>

      <div className="mb-8 rounded-xl border bg-white p-6 shadow-sm">
        <h2 className="mb-4 text-lg font-semibold">Create a new coupon</h2>
        <NewCouponForm merchantId={merchant.id} />
      </div>

      <h2 className="mb-4 text-lg font-semibold">Your coupons</h2>
      <div className="overflow-x-auto rounded-xl border bg-white shadow-sm">
        <table className="w-full min-w-[600px] text-left text-sm">
          <thead className="bg-gray-50 text-xs uppercase text-gray-500">
            <tr><th className="px-4 py-3">Title</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Redemptions</th><th className="px-4 py-3">Expires</th></tr>
          </thead>
          <tbody>
            {(coupons ?? []).map((coupon) => (
              <tr key={coupon.id} className="border-t">
                <td className="px-4 py-3 font-medium">{coupon.title}</td>
                <td className="px-4 py-3 capitalize">{coupon.status ?? "—"}</td>
                <td className="px-4 py-3">{coupon.total_redemptions ?? 0}</td>
                <td className="px-4 py-3">{coupon.expires_at ? new Date(coupon.expires_at).toLocaleDateString() : "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}