"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function NewCouponForm({ merchantId }: { merchantId: string }) {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [expiresAt, setExpiresAt] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage(null);

    const { error } = await createClient().from("coupons").insert({
      merchant_id: merchantId,
      title,
      description: description || null,
      expires_at: expiresAt ? new Date(`${expiresAt}T23:59:59`).toISOString() : null,
      status: "active"
    });

    setSaving(false);

    if (error) {
      setMessage(error.message);
      return;
    }

    setTitle("");
    setDescription("");
    setExpiresAt("");
    setMessage("Coupon created.");
    router.refresh();
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div>
        <label className="mb-1 block text-sm font-medium">Title</label>
        <input required value={title} onChange={(e) => setTitle(e.target.value)} className="w-full rounded-lg border px-3 py-2 text-sm" placeholder="20% off your next visit" />
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium">Description</label>
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} className="min-h-24 w-full rounded-lg border px-3 py-2 text-sm" placeholder="Offer details and restrictions" />
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium">Expiration date</label>
        <input type="date" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} className="rounded-lg border px-3 py-2 text-sm" />
      </div>
      {message && <p className="text-sm">{message}</p>}
      <button disabled={saving} className="rounded-lg bg-brand-600 px-5 py-2.5 font-medium text-white hover:bg-brand-700 disabled:opacity-60">{saving ? "Creating..." : "Create Coupon"}</button>
    </form>
  );
}