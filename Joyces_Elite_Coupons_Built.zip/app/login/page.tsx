import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import LoginForm from "./login-form";

export default async function LoginPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (user) redirect("/");
  return (
    <div className="mx-auto max-w-sm">
      <h1 className="mb-6 text-2xl font-bold">Sign In</h1>
      <LoginForm />
      <p className="mt-4 text-center text-sm text-gray-500">
        Don't have an account? <a href="/signup" className="font-medium text-brand-600">Sign up</a>
      </p>
    </div>
  );
}