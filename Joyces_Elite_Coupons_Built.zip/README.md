# Joyce's Elite Coupons

Next.js + Supabase coupon platform.

## Included

- Public active-coupon browsing
- Coupon detail pages
- Supabase email/password authentication
- Email confirmation callback
- Customer coupon saves and redemption tokens
- Merchant dashboard
- Merchant coupon creation
- Merchant redemption screen using `redeem_coupon`
- Supabase SSR cookie/session handling
- Tailwind styling
- Safe redirect handling in the auth callback

## Setup

1. Copy `.env.example` to `.env.local`.
2. Add your Supabase project URL and publishable/anon key.
3. Make sure your existing Supabase tables and RLS policies match the fields used by the app.
4. Make sure your `redeem_coupon` RPC accepts:
   - `p_redemption_token`
   - `p_merchant_id`
5. Install dependencies:

```bash
npm install
```

6. Run:

```bash
npm run dev
```

7. Production build:

```bash
npm run build
```

Do not put a Supabase service-role key in `.env.local` or any `NEXT_PUBLIC_*` variable.
